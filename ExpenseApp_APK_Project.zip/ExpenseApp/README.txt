HOW TO GET THE APK (no coding needed)
1. Create a free account at github.com, make a NEW repository.
2. Upload ALL files/folders of this project (keep the folder structure, including the hidden .github folder).
3. Open the repository > Actions tab > "Build APK" runs automatically (about 3-5 minutes).
4. Open the finished run > Artifacts > download "Routine-Expense-APK" (a zip), unzip it to get app-debug.apk.
5. Copy the APK to your Android phone, open it, allow "Install unknown apps" for your file manager/browser, and install.

Or open this folder in Android Studio > Build > Build APK(s).
Requires Android 10 or newer.
To change the app later: replace app/src/main/assets/index.html and build again.
