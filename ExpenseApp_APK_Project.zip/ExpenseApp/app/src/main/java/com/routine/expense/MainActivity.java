package com.routine.expense;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView wv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (wv.canGoBack()) wv.goBack(); else super.onBackPressed();
    }

    private Uri save(String b64, String name) throws Exception {
        byte[] data = Base64.decode(b64, Base64.DEFAULT);
        ContentResolver cr = getContentResolver();
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new Exception("Cannot create file");
        try (OutputStream o = cr.openOutputStream(uri)) { o.write(data); }
        return uri;
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show(); } });
    }

    public class Bridge {
        @JavascriptInterface
        public void savePdf(String b64, String name) {
            try { save(b64, name); toast("Saved to Downloads: " + name); }
            catch (Exception e) { toast("Could not save PDF"); }
        }

        @JavascriptInterface
        public void viewPdf(String b64, String name) {
            try {
                final Uri u = save(b64, name);
                runOnUiThread(new Runnable() { public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(u, "application/pdf");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, "Open PDF"));
                    } catch (Exception e) { toast("No PDF viewer installed. File saved in Downloads."); }
                } });
            } catch (Exception e) { toast("Could not open PDF"); }
        }

        @JavascriptInterface
        public void sharePdf(String b64, String name) {
            try {
                final Uri u = save(b64, name);
                runOnUiThread(new Runnable() { public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("application/pdf");
                    i.putExtra(Intent.EXTRA_STREAM, u);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Share PDF"));
                } });
            } catch (Exception e) { toast("Could not share PDF"); }
        }

        @JavascriptInterface
        public void shareMany(String json) {
            try {
                JSONArray a = new JSONArray(json);
                final ArrayList<Uri> L = new ArrayList<Uri>();
                for (int k = 0; k < a.length(); k++) {
                    JSONObject o = a.getJSONObject(k);
                    L.add(save(o.getString("b"), o.getString("n")));
                }
                runOnUiThread(new Runnable() { public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    i.setType("application/pdf");
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, L);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Share PDFs"));
                } });
            } catch (Exception e) { toast("Could not share PDFs"); }
        }
    }
}
